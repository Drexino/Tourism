using Xamarin.Forms;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
[assembly: ExportFont("fa-solid-900.otf", Alias = "FAS")]
[assembly: ExportFont("fa-regular-400.otf", Alias = "FAR")]
[assembly: ExportFont("fa-brands-regular-400.otf", Alias = "FAB")]