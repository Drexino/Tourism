﻿using System;
using Xamarin.Forms;

namespace Tourism
{
    public class myScrollView: ScrollView
    {
    }
}
