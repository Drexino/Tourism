﻿using System;
using System.Collections.Generic;
using System.Text;
using Tourism.Interfaces;

namespace Tourism.MessagerModels
{
    public class FlyoutMenuTapped : IMessage
    {
    }
}
