﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tourism.Interfaces
{
    public interface IApp
    {
        string CurrentAccessToken { get; set; }
    }
}
